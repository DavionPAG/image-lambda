# Lab 17 ==> AWS: S3 and Lambda

<!-- a description of how to use your lambda. -->

<!-- a description of any issues you encountered during deployment of this lambda. -->

<!-- an image and thumbnail that your Lambda processed -->
